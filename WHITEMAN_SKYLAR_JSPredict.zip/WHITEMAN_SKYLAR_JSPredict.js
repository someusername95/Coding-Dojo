//Predict 1 = syntax error? combining string and int with no concatenation?
//Predict 2 = I was born in 1980       // no period given
//Predict 3 = Summing numbers!
            //num1 is: 10
            //num2 is: 20
            //30
            